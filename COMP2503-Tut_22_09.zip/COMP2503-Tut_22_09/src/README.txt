**PART 1**

1. How many concepts or possible objects you can identify from the above description? List
them all:
	- department
	- students
	- instructors
	- inheritance

7. What relationship does exist between the department and the students?
	- Aggregation 

9. Did you use polymorphism in your code? Explain where and how?
	- Yes, we use polymorphism when convertind Students/Instructors into Persons, or the other way around. 

	
	
**PART 2**

