package model;

public interface Measurable {
	
	public abstract void getAmount();
	
}
